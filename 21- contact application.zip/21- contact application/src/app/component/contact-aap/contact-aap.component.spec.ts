import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactAapComponent } from './contact-aap.component';

describe('ContactAapComponent', () => {
  let component: ContactAapComponent;
  let fixture: ComponentFixture<ContactAapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContactAapComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactAapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
