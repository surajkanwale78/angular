import { Component, OnInit } from '@angular/core';
import { Contact } from 'src/app/models/Contact';

@Component({
  selector: 'app-contact-aap',
  templateUrl: './contact-aap.component.html',
  styleUrls: ['./contact-aap.component.css']
})
export class ContactAapComponent implements OnInit {
  public selectedContact:Contact = {} as Contact

  constructor() { }

  ngOnInit(): void {
  }
  
  
  
}
