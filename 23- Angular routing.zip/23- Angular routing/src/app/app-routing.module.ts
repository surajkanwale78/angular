import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './component/about/about.component';
import { ContactListComponent } from './component/contact-list/contact-list.component';
import { HomeComponent } from './component/home/home.component';

const routes: Routes = [
  
  {path : '' , component : HomeComponent},
  {path : 'contacts' , component :ContactListComponent },
  {path : 'about' , component : AboutComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
